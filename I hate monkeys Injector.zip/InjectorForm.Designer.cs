namespace CoolInjectorWinForms
{
    partial class InjectorForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button btnSelectProcess;
        private System.Windows.Forms.Button btnSelectDll;
        private System.Windows.Forms.Button btnInject;
        private System.Windows.Forms.Button btnUnload;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InjectorForm));
            btnSelectProcess = new System.Windows.Forms.Button();
            btnSelectDll = new System.Windows.Forms.Button();
            btnInject = new System.Windows.Forms.Button();
            btnUnload = new System.Windows.Forms.Button();
            logBox = new System.Windows.Forms.TextBox();
            SuspendLayout();
            // 
            // btnSelectProcess
            // 
            btnSelectProcess.Location = new System.Drawing.Point(12, 12);
            btnSelectProcess.Name = "btnSelectProcess";
            btnSelectProcess.Size = new System.Drawing.Size(200, 30);
            btnSelectProcess.TabIndex = 0;
            btnSelectProcess.Text = "Select EXE";
            btnSelectProcess.Click += btnSelectProcess_Click;
            // 
            // btnSelectDll
            // 
            btnSelectDll.Location = new System.Drawing.Point(12, 48);
            btnSelectDll.Name = "btnSelectDll";
            btnSelectDll.Size = new System.Drawing.Size(200, 30);
            btnSelectDll.TabIndex = 1;
            btnSelectDll.Text = "Select DLL";
            btnSelectDll.Click += btnSelectDll_Click;
            // 
            // btnInject
            // 
            btnInject.Location = new System.Drawing.Point(12, 84);
            btnInject.Name = "btnInject";
            btnInject.Size = new System.Drawing.Size(95, 30);
            btnInject.TabIndex = 2;
            btnInject.Text = "Inject";
            btnInject.Click += btnInject_Click;
            // 
            // btnUnload
            // 
            btnUnload.Location = new System.Drawing.Point(117, 84);
            btnUnload.Name = "btnUnload";
            btnUnload.Size = new System.Drawing.Size(95, 30);
            btnUnload.TabIndex = 3;
            btnUnload.Text = "Unload";
            btnUnload.Click += btnUnload_Click;
            // 
            // logBox
            // 
            logBox.Location = new System.Drawing.Point(12, 120);
            logBox.Multiline = true;
            logBox.Name = "logBox";
            logBox.ReadOnly = true;
            logBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            logBox.Size = new System.Drawing.Size(400, 200);
            logBox.TabIndex = 4;
            logBox.Text = "Log:\n";
            logBox.TextChanged += logBox_TextChanged;
            // 
            // InjectorForm
            // 
            BackgroundImage = (System.Drawing.Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new System.Drawing.Size(424, 341);
            Controls.Add(btnSelectProcess);
            Controls.Add(btnSelectDll);
            Controls.Add(btnInject);
            Controls.Add(btnUnload);
            Controls.Add(logBox);
            Icon = (System.Drawing.Icon)resources.GetObject("$this.Icon");
            Name = "InjectorForm";
            Text = "I Hate monkeys";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.TextBox logBox;
    }
}
