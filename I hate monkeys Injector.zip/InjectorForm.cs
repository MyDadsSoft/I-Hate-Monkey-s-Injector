using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CoolInjectorWinForms
{
    public partial class InjectorForm : Form
    {
        private string selectedProcessPath = "";
        private string selectedDllPath = "";

        public InjectorForm()
        {
            InitializeComponent();
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpAddress,
            uint dwSize, uint flAllocationType, uint flProtect);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress,
            byte[] lpBuffer, uint nSize, out UIntPtr lpNumberOfBytesWritten);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr CreateRemoteThread(IntPtr hProcess,
            IntPtr lpThreadAttributes, uint dwStackSize, IntPtr lpStartAddress,
            IntPtr lpParameter, uint dwCreationFlags, IntPtr lpThreadId);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr GetProcAddress(IntPtr hModule, string lpProcName);

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr GetModuleHandle(string lpModuleName);

        const int PROCESS_ALL_ACCESS = 0x1F0FFF;
        const uint MEM_COMMIT = 0x00001000;
        const uint PAGE_READWRITE = 4;

        private void btnSelectProcess_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Executable Files (*.exe)|*.exe";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                selectedProcessPath = ofd.FileName;
                logBox.AppendText("\nSelected EXE: " + selectedProcessPath);
            }
        }

        private void btnSelectDll_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "DLL Files (*.dll)|*.dll";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                selectedDllPath = ofd.FileName;
                logBox.AppendText("\nSelected DLL: " + selectedDllPath);
            }
        }

        private void btnInject_Click(object sender, EventArgs e)
        {
            if (!File.Exists(selectedDllPath))
            {
                MessageBox.Show("Select a valid DLL.");
                return;
            }

            Process process = Process.Start(selectedProcessPath);
            System.Threading.Thread.Sleep(1000); // wait for process to load

            IntPtr hProcess = OpenProcess(PROCESS_ALL_ACCESS, false, process.Id);
            IntPtr addr = VirtualAllocEx(hProcess, IntPtr.Zero, (uint)((selectedDllPath.Length + 1) * sizeof(char)), MEM_COMMIT, PAGE_READWRITE);

            WriteProcessMemory(hProcess, addr, System.Text.Encoding.ASCII.GetBytes(selectedDllPath), (uint)((selectedDllPath.Length + 1) * sizeof(char)), out _);

            IntPtr loadLibAddr = GetProcAddress(GetModuleHandle("kernel32.dll"), "LoadLibraryA");
            CreateRemoteThread(hProcess, IntPtr.Zero, 0, loadLibAddr, addr, 0, IntPtr.Zero);

            logBox.AppendText("\nDLL Injected.");
        }

        private void btnUnload_Click(object sender, EventArgs e)
        {
            logBox.AppendText("\nUnload not implemented.");
        }

        private void logBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
